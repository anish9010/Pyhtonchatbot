// ChatPopup.js
import React, { useState } from 'react';
import './App.css'; // Import the CSS file

function ChatPopup({ chatVisible, toggleChatbot }) {
  const [userInput, setUserInput] = useState('');
  const [chatbotResponse, setChatbotResponse] = useState('');
  const [showOptions, setShowOptions] = useState(false);

  // Handles sending the message
  const sendMessage = () => {
    const validGreetings = ['hey', 'hi', 'hello', 'how are you'];
    if (userInput.trim()) {
      const normalizedInput = userInput.trim().toLowerCase();
      if (validGreetings.includes(normalizedInput)) {
        setChatbotResponse('Hello! Please choose from the following options:');
        setShowOptions(true);
      } else {
        setChatbotResponse('Please enter a valid response to start the chat.');
        setShowOptions(false);
      }
    }
  };

  // Handles selecting an option
  const handleOptionSelect = (option) => {
    switch (option) {
      case 'Railway Scheme':
        setChatbotResponse(
          <>
            All the railway schemes are present at the website: 
            <a href="https://www.railway.co.in" target="_blank" rel="noopener noreferrer">
              www.railway.co.in
            </a>
          </>
        );
        break;
      case 'Government Scheme':
        setChatbotResponse(
          <>
            All the government schemes are present at the website: 
            <a href="https://www.government.co.in" target="_blank" rel="noopener noreferrer">
              www.Government.co.in
            </a>
          </>
        );
        break;
      case 'Electricity Board Scheme':
        setChatbotResponse(
          <>
            All the electricity board schemes are present at the website: 
            <a href="https://www.electricity_board.co.in" target="_blank" rel="noopener noreferrer">
              www.Electricity_Board.co.in
            </a>
          </>
        );
        break;
      case 'Finance Scheme':
        setChatbotResponse(
          <>
            All the finance schemes are present at the website: 
            <a href="https://www.finance.co.in" target="_blank" rel="noopener noreferrer">
              www.Finance.co.in
            </a>
          </>
        );
        break;
      default:
        setChatbotResponse('Invalid option selected.');
        break;
    }
    setShowOptions(false);
  };

  // Clears the chat area
  const clearChat = () => {
    setUserInput('');
    setChatbotResponse('');
    setShowOptions(false);
  };

  return (
    chatVisible && (
      <div className="chatbox-style">
        <div className="chat-header-style">
          <h3>Deepak_Yadav_Chat_Process</h3>
          <button onClick={toggleChatbot} className="close-button-style">
            X
          </button>
        </div>
        <div className="chat-area-style">
          {chatbotResponse && <p><strong>Bot:</strong> {chatbotResponse}</p>}
        </div>
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Type a message"
          className="input-style"
        />
        <div className="button-container-style">
          <button onClick={sendMessage} className="send-button-style">
            Send
          </button>
          <button onClick={clearChat} className="clear-button-style">
            Clear
          </button>
        </div>

        {showOptions && (
          <div className="options-style">
            <button onClick={() => handleOptionSelect('Railway Scheme')} className="option-button-style">
              Option 1: Railway Scheme
            </button>
            <button onClick={() => handleOptionSelect('Government Scheme')} className="option-button-style">
              Option 2: Government Scheme
            </button>
            <button onClick={() => handleOptionSelect('Electricity Board Scheme')} className="option-button-style">
              Option 3: Electricity Board Scheme
            </button>
            <button onClick={() => handleOptionSelect('Finance Scheme')} className="option-button-style">
              Option 4: Finance Scheme
            </button>
          </div>
        )}
      </div>
    )
  );
}

export default ChatPopup;
