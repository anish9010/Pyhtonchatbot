// App.js
import React, { useState } from 'react';
import ButtonComponent from './ButtonComponent';
import ChatPopup from './ChatPopup';
import './App.css'; // Import the CSS file

function App() {
  const [chatVisible, setChatVisible] = useState(false);

  // Toggles the chatbot popup
  const toggleChatbot = () => {
    setChatVisible(!chatVisible);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Chatbot Interface</h1>
      {/* Button positioned in the bottom-right corner */}
      <div className="button-container">
        <ButtonComponent toggleChatbot={toggleChatbot} />
      </div>
      <ChatPopup chatVisible={chatVisible} toggleChatbot={toggleChatbot} />
    </div>
  );
}

export default App;
