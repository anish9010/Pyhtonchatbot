// ButtonComponent.js
import React from 'react';
import './App.css'; // Import the CSS file

function ButtonComponent({ toggleChatbot }) {
  return (
    <button onClick={toggleChatbot} className="button-style">
      Deepak Button
    </button>
  );
}

export default ButtonComponent;
